package org.example.tools.abstractions;

import org.example.model.Geography;

public interface IParse<TResult extends Geography> {

    Geography parse(String input);
}
