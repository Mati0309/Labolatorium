package org.example.tools.geographies;

import org.example.model.Geography;
import org.example.tools.abstractions.IParse;

public class GeographyParser implements IParse<Geography> {
    @Override
    public Geography parse(String input) {
        Geography geography = new Geography();
        geography.setId(Integer.parseInt(input));
        geography.setName(input);
        geography.setType(input);
        geography.setCode(input);
        geography.setParentId(Integer.parseInt(input));

        return geography;
    }

}
