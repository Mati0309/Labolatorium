package org.example.model;

public enum Gender {
    MALE, FEMALE
}
