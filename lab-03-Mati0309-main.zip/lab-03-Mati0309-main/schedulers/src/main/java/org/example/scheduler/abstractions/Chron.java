package org.example.scheduler.abstractions;




import java.time.Duration;
import java.time.LocalDateTime;


public class Chron{
    LocalDateTime startTime;
    LocalDateTime endDate;
    int maxExecutionTimes;
    Duration intervalDuration;




    public Chron setStartTime(LocalDateTime startTime) {
     this.startTime = startTime;
     return this;
 }

 public Chron setEndDate(LocalDateTime endDate) {
     this.endDate = endDate;
     return this;
 }
 public Chron setMaxExecutionTimes(int maxExecutionTimes) {
     this.maxExecutionTimes = maxExecutionTimes;
     return this;
 }
 public Chron setIntervalDuration(Duration intervalDuration) {
     this.intervalDuration = intervalDuration;
     return this;
 }




    public static Chron builder() {
        return new Chron();
    }

    public IProvideNextExecutionTime buildNextTimeExecutionProvider() {
    }
}
